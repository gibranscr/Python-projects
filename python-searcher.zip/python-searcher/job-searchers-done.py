#!/usr/bin/env python
# coding: utf-8

# In[2]:


#!/usr/bin/env python
# coding: utf-8

#!/usr/bin/env python3
import feedparser
import bs4
import requests
from bs4 import BeautifulSoup
import csv
import xlsxwriter
import re
from urllib.parse import urlparse
import urllib.request
import validators
#open excel with websites to get urls EXCEL FILES USER job-searchers.xlsx AND website-searched.xlxs
import openpyxl
global d
global urlres
global url_cleaned
global found
from urllib.request import urlopen, URLError
import urllib.request as req
import urllib.parse as p

def checkjob(url_cleaned,jobtitle):
    wb=openpyxl.load_workbook("website-searched.xlsx")
    ws=wb["Sheet1"]
    global found
    for jobdb in ws.iter_rows():
        jobdata0=jobdb[0].value
        jobdata1=jobdb[1].value
        #print(jobdata)
        #print(jobtitle)
        if url_cleaned==jobdata1 and jobdata0==jobtitle:
        #if jobtitle==jobdata:          
            found="It already exists"
            break
        else:
            found="It does not exist"
    return found

from urllib.request import urlopen, URLError

def validate_web_url(url_cleaned):
    try:
        urlopen(url_cleaned)
        return True
    except:
        pass
message=""
items=[]
titlej=""
msg=""

print('process started')

wbw = openpyxl.load_workbook('job-searchers.xlsx')
wss=wbw['Sheet1']
for web in wss.iter_rows():
    website=web[0].value
    #type_ws=web[1].value
    
    
    #-----identify the website name in order to select the section to extract the job description
    data = urlparse(website)
    #name_website='www.careerbuilder.com'
    name_website=data.netloc
    print(name_website)
    urlwebsite=website
    var=input("Enter keywords:")
    location=input("location:")#
    number_pages=input("Number of Pages Analyzed 25 Results per Page:")
    date_posted=input("Date posted 3,7,24 or 30 days:")
    #var='chemical+engineer'
    #    urlwebsite=https://www.careerbuilder.com/jobs?utf8=%E2%9C%93&keywords
    i=1
    number_page=int(number_pages)
    for i in range(number_page):
        i+=1
        url = website+var+'&location='+location+'&page_number='+str(i)+'&posted='+date_posted

        headers = {
            'User-Agent': 'IE 11.0',
           # 'From': 'youremail@domain.com'  # This is another valid field
        }

        response = requests.get(url, headers=headers)

        content_type = response.headers['Content-Type'].lower()  
        #---get content from webpage
        content_types=response.content
        html=BeautifulSoup(content_types,'html.parser')
        #html_str=str(html)
        #print(html)
        print(url)
    #----career builder-------------
        #wb = openpyxl.load_workbook('websites4.xlsx')
        #ws=wb['Sheet1']


        #for link in html.findAll('a',attrs={'href',re.compile("https://")}):
        # iterate over all the links found on the page
        for link in html.findAll('a'):
            page=link.get('href')
            pagestr=str(page)
            #select the urls that start with http or https and ignore case sensitive
            regex = re.compile(r'^(?:http|ftp)s?://',re.IGNORECASE)

            #print(pagestr)
            #print(ss)
            #match the urls obtained from the url given to get job published and not pages of infor, news or articles
            if re.match(regex, page) is not None:
                #search wher the = starts in the url
                m = re.search(r'(?<==)', pagestr)
                if m is not None:
                    #split the url found with = and show the second part this is specifically for careerbuilder
                    url_cleaned= re.split(r'(?<==)', pagestr)[1]

                    if validate_web_url(url_cleaned)==True:

                        #obtain the content from the url splitted and found
                        response = requests.get(url_cleaned, headers=headers)
                        content_type = response.headers['Content-Type'].lower()  
                        #---get content from webpage
                        content_types=response.content
                        html=BeautifulSoup(content_types,'html.parser')

                        html_str=str(html)
                        #print("texto::")
                        #print(url_cleaned)
                        keywords=['master in business administration']
                        #keywords={'mba'}
                        #keywords=[var]
                        #evaluate the keywords in the text
                        #if raw.find(keywords)>-1:
                        if all(x in html_str for x in keywords):
                            #print(content_types.find(word))
                            #name_website="rss.jobsearch.monster.com"
                            if name_website=="www.careerbuilder.com":
                            #if message!="":
                                #print(page)
                                try:
                                    message = html.find('div',attrs={'id':'jdp_description'}).text
                                    titlej = html.find('h1',attrs={'class':'h3 dark-blue-text b'}).text

                                except Exception as e:
                                    if hasattr(e, 'message'):
                                        print("")
                                    else:
                                        print("")
                            #if message!=None or message!="":           
                            #Clean html obtained from the job description
                            if message!='':
                                cleanr = re.compile('<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});')
                                msg = re.sub(cleanr, '', message)

                                items=[titlej,url_cleaned,msg]

                            #print("url")
                            #print(url_cleaned)
                            #print(msg)
                            
                            if titlej!="" and url_cleaned!="" and msg!="":
                                jobtitle=titlej
                                checkjob(url_cleaned,jobtitle)
                                print("title:")
                                print(jobtitle)
                                print(url_cleaned)
                                print(found)
                                if found=="It does not exist":
                                    #if html_str.find(word)>-1:
                                    #if any(x in html_str for x in keywords):
                                    print("title:")
                                    print(jobtitle)
                                    print(url_cleaned)
                                    #print('Msg:')
                                    #print(msg)

                                    wb=openpyxl.load_workbook("website-searched.xlsx")
                                    ws=wb["Sheet1"]
                                    ws2=wb.active
                                    ws2.append(items)
                                    wb.save("website-searched.xlsx")

print("finished")        
        


# 

# In[ ]:





# In[ ]:




