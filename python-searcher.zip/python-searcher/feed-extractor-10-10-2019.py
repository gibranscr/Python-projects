#!/usr/bin/env python
# coding: utf-8

# In[2]:


#!/usr/bin/env python
# coding: utf-8

#!/usr/bin/env python3
import feedparser
import bs4
import requests
from bs4 import BeautifulSoup
import csv
import xlsxwriter
import re
from urllib.parse import urlparse
import urllib.request
import validators
#open excel with websites to get urls
import openpyxl
global d
global urlres
global found
from urllib.request import urlopen, URLError
import urllib.request as req
import urllib.parse as p

def checkjob(jobtitle):
    wb=openpyxl.load_workbook("websites4.xlsx")
    ws=wb["Sheet1"]
    global found
    for jobdb in ws.iter_rows():
        jobdata=jobdb[0].value
        #print(jobdata)
        #print(jobtitle)
        if jobtitle==jobdata:          
            found="It already exists"
            break
        else:
            found="It does not exist"
    return found

message=""
msg2=""
items=[]
#d=feedparser.parse('https://media.newjobs.com/mm/mps/newspapers/NewsFeed_Minimum_Required_Sample.xml')
#print(d['feed']['job']['jobrefcode'])
#----Monster feed
#keyword='engineer'
#country='us'
#city='Portland'
#state='OR'
#d=feedparser.parse('http://rss.jobsearch.monster.com/rssquery.ashx?brd=1&q='+keyword+'&cy='+country+'&where='+city+'&where='+state+'')
#print(d)
#print(d['entries']['title'])
#for job in d.entries:
#    print(job.title)
#    print(job.summary)
#    print(job.link)
wbw = openpyxl.load_workbook('website-official-good.xlsx')
wss=wbw['Sheet1']
#input for keywords
#var=input("Enter keywords:")
var=""
for web in wss.iter_rows():
    website=web[0].value
    #type_ws=web[1].value
    
    
    #-----identify the website name in order to select the section to extract the job description
    data = urlparse(website)
    name_website=data.netloc
    print(name_website)
    urlwebsite=website
    website=website+var
    
    print(website)
    
#----career builder-------------
#keywords='engineer'
#location='Portland%2COr'
#https://www.careerbuilder.com/RTQ/rss20.aspx?keywords=engineer&location=Portland%2COr
    #d=feedparser.parse('https://www.careerbuilder.com/RTQ/rss20.aspx?keywords=engineer&location=Portland%2COr')
    #d=feedparser.parse('https://www.careerbuilder.com/RTQ/rss20.aspx?keywords='+keywords+'&location='+location+'')
    #d=feedparser.parse('http://rss.jobsearch.monster.com/rssquery.ashx?q=Web%20Developer')
    #d=feedparser.parse('http://www.indeed.com/rss?q=telecommute&l=Canoga+Park%2C+CA&radius=100')
    #print(website)
    #if type_ws=="FeedRss":
    #assign the keywords obtained to the url stored
    #--------------------------
    #if name_website=="www.monster.com":
        #website = website+var
    #elif name_website=="www.careerbuilder.com":
        #website = website+var
    #-----------------------
    #analyze the url
    d=feedparser.parse(website)

    wb = openpyxl.load_workbook('websites4.xlsx')
    ws=wb['Sheet1']
    print('process started')
    for job in d.entries:
            #    print(job.title)
            #    print(job.summary)
            #    print(job.link)
                #for postss in job.link
        page=job.link
        titlej=job.title
        
        raw_html = requests.get(page)
        content_type = raw_html.headers['Content-Type'].lower()  
        #---get content from webpage
        content_types=raw_html.content
        html=BeautifulSoup(content_types,'html.parser')
        html_str=str(html)
        #Look for keyword in the add
        #print(html_str)
        
        
        keywords={" master "}
        
        
        #keywords={'mba, master in business administration, masters'}
        #evaluate the keywords in the text
        #if html_str.find(word)>-1:
        if any(x in html_str for x in keywords):
            if name_website=="www.careerbuilder.com":
                try:
                    message = html.find('script',attrs={'type':'application/ld+json'}).text
                    
                except Exception as e:
                    if hasattr(e, 'message'):
                        print("")
                    else:
                        print("")
                        
            #careerbuilder website
            #message = html.find('script',attrs={'type':'application/ld+json'})
            #msg = message.text
            #if name_website=="rss.jobsearch.monster.com":
            if name_website=="rss.jobsearch.monster.com":
                try:
                    message=html.find('span',attrs={'id':'TrackingJobBody'}).text
                except Exception as e:
                    #print("None")
                    if hasattr(e, 'message'):
                    #    print(e,message)
                        print("")
                    else:
                        print("")
            if name_website=="www.engineer.net":
                try:
                    message=html.find('table',attrs={'width':'717'}).text
                except Exception as e:
                    #print("None")
                    if hasattr(e, 'message'):
                    #    print(e,message)
                        print("")
                    else:
                        print("")
            if name_website=="www.jobs.ac.uk":
                try:
                    message=html.find('div',attrs={'id':'job-description'}).text
                except Exception as e:
                    #print("None")
                    if hasattr(e, 'message'):
                    #    print(e,message)
                        print("")
                    else:
                        print("")
            if name_website=="www.gulftalent.com":
                try:
                    message=html.find('div',attrs={'class':'panel-body'}).text
                except Exception as e:
                    #print("None")
                    if hasattr(e, 'message'):
                    #    print(e,message)
                        print("")
                    else:
                        print("")
            
            #if message!=None or message!="":           
                #Clean html obtained from the job description
            if message!='':
                cleanr = re.compile('<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});')
                msg2 = re.sub(cleanr, '', message)
            #msg = message.text
                #save values in an array     
                items=[titlej,page,msg2]
        jobtitle=titlej
        checkjob(jobtitle)
        #print("Passed URl:")
        #print(page)
        #print("Message:")
        #print(message)
        if found=="It does not exist":
            #if html_str.find(word)>-1:
            if any(x in html_str for x in keywords):
                print(jobtitle)
                wb=openpyxl.load_workbook("websites4.xlsx")
                ws=wb["Sheet1"]
                ws2=wb.active
                ws2.append(items)
                wb.save("websites4.xlsx")
            #else:
                #It is not in the document,but the keywords are not contained in the content
                #print("No incluido")
            #ws2=wb.active
            #ws2.append(items)
            #wb.save("websites4.xlsx")
print('Finished1')

#def validate_web_urls(url):
#    try:
#        urlopen(url)
#        d= link['href']
#        return d
#    except Exception as ValueError:
#        d=None
#        return d

#jobtitle="Software Engineer - Multi-disciplinary - IV"
#jobtitles=["Site4"]
#jobtitle=jobtitles[0]
#jobtitle=items[0]
#checkjob(jobtitle)
#if found=="It does not exist":
#     print(jobtitle)
#     wb=openpyxl.load_workbook("websites4.xlsx")
#     ws=wb["Sheet1"]
#     ws2=wb.active
#     ws2.append(jobtitles)
#     wb.save("websites4.xlsx")
print("Finished2")


# In[ ]:





# In[ ]:





# In[ ]:




